<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>


<?php
/* Php Array for Coordinates */
    $data = array(0=>array('Bondi Beach', -33.890542, 151.274856, 4),
        1=>array('Coogee Beach', -33.923036, 151.259052, 5),
        2=>array('Cronulla Beach', -34.028249, 151.157507, 3),
        3=>array('Manly Beach', -33.80010128657071, 151.28747820854187, 2),
        4=>array('Maroubra Beach', -33.950198, 151.259302, 6));
    $json_string = json_encode($data);
?>

<!-- Canvas for Where Map populate -->
<div id="map" style="width: 100%; height: 400px;"></div>

<script>
var locations = JSON.parse( '<?php echo $json_string ?>' );

/* // Array for Coordinates
var locations = [
    ['Bondi Beach', -33.890542, 151.274856, 4],
    ['Coogee Beach', -33.923036, 151.259052, 5],
    ['Cronulla Beach', -34.028249, 151.157507, 3],
    ['Manly Beach', -33.80010128657071, 151.28747820854187, 2],
    ['Maroubra Beach', -33.950198, 151.259302, 1]
];
*/
var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 10,
    center: new google.maps.LatLng(locations[0][1], locations[0][2]),
    mapTypeId: google.maps.MapTypeId.ROADMAP
});
var infowindow = new google.maps.InfoWindow();
var marker, i;
for (i = 0; i < locations.length; i++) {
    marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: {
          path: google.maps.SymbolPath.CIRCLE, //Circle Area Pointer
          scale: locations[i][3]*2,
          strokeOpacity: 0.8,
          strokeWeight: 2,
          fillColor: '#FF0000',
          fillOpacity: 0.35,
        },
        // draggable: true,
        map: map,
    });
    google.maps.event.addListener(marker, 'mouseover', (function (marker, i) {
        return function () {
            infowindow.setContent(locations[i][0]+" "+locations[i][3]+"x2");
            infowindow.open(map, marker);
        }
    })(marker, i));
}
</script>
