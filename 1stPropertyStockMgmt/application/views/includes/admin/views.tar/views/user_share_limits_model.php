<?php
class User_share_limits_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	function getsharepropertylimits($userid, $propertyid)
	{
		$this -> db -> select('*');
		$this -> db -> from('user_share_limits');
		$this->db->where('user_id', $userid);
		$this->db->where('property_id', $propertyid);
		$query = $this->db->get();		
		return $query->row_array(); 	
	}
	
	public function get_share_limit_by_id($id)
    {
		$this->db->select('*');
		$this->db->from('user_share_limits');
		$this->db->where('id', $id);
		$query = $this->db->get();
		return $query->result_array(); 
    }
	
	public function store_user_share_limit($data)
    {
		$insert = $this->db->insert('user_share_limits', $data);
	    return $insert;
	}
	
	public function get_share_limit()
    {	    
		$this->db->select('*');
		$this->db->from('user_share_limits');	       
		$query = $this->db->get();
		
		return $query->result_array(); 	
    }
	
	function update_share_limit($id, $data)
    {
		$this->db->where('id', $id);
		$this->db->update('user_share_limits', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}

    function delete_share_limit($id){
		$this->db->where('id', $id);
		$this->db->delete('user_share_limits'); 
	}
}